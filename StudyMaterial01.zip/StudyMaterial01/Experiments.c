
#include <stdio.h>

//_______________________________________________

// void authentication( username, password ) {
	// username = "default;
	// password = "dfdfdfdfd";

void playWithArrays() {
	// 0 to 4
	int a[5] = { 10, 20, 30, 40, 50 };

	// if ( MIN_INDEX < index < MAX_INDEX )
	int some_element = a[9];
	printf("\n Value: %d ", some_element);

	some_element = a[ -5 ];
	printf("\n Value: %d ", some_element);
}

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________

void main() {
	printf("\nFunction: playWithArrays");
	playWithArrays();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}

