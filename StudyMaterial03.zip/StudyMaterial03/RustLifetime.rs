

//_____________________________________________________________


// Borrow Checker
//  The Rust compiler has a borrow checker that 
//      compares scopes to determine whether all borrows are valid

// Expected Good Relationship
// 		Lifetime Of r >= Lifetime of a

// Actual Relationship
// 		Lifetime Of r < Lifetime of a

/*
fn play_with_lifetime() {
	let r;   // Lifetime : 'a

	{
		let x = 50;  // Lifetime: 'b
		r = &x;
	}

	println!("Value r: {r}");
}
*/

//_____________________________________________________________

fn play_with_lifetime() {
	let r;   // Lifetime : 'a

	let x = 50;  // Lifetime: 'b
	r = &x;

	println!("Value r: {r}");
}

//_____________________________________________________________

// fn longest( x: &str, y: &str ) -> &str {
fn longest<'a>( x: &'a str, y: &'a str ) -> &'a str {
	if x.len() > y.len() {
		x 
	} else {
		y
	}
}


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________


fn main() {
	println!("\nFunction : play_with_lifetime");
	play_with_lifetime();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}

