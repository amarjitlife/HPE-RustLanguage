

//_____________________________________________________________

fn play_with_scope() { // Outer Scope
	// Allocate Object At Stack
	let greeting = "Good Evening!!!";
	println!("Hey: {greeting}" );

	// // Allocate Object At Heap
	let hello = String::from("Hello More");
	println!("Hey: {hello}");

	{ // Inside/Local Scope
		let hello = "Hello!";
		println!("Hey: {hello}" );
	} // Inside Scope Ends

	// error[E0425]: cannot find value `hello` in this scope
	println!("Hey: {hello}" );

	let hello = 999;
	println!("Hey: {hello}" );	
}


//_____________________________________________________________

fn play_with_scope_again() { // Outer Scope
	// Allocate Object At Stack
	let greeting = "Good Evening!!!";
	println!("Hey: {greeting}" );

	let hello = greeting;  // Copy Symantics i.e. It Will Duplicate Object
	println!("Hey: {hello}" );
	println!("Hey: {greeting}" );

	// Allocate Object At Heap
	//		greeting1 is Reference to String Type Object At Heap
	//		greeting1 is Stored At Stack
	//		greeting1 is Owner of String Type Object At Heap
	//				String Type Object Value 
	//		greeting1 -----> [ "Good Evening!!!" ]

	let greeting1 = String::from("Good Evening!!!");
	println!("Hey: {greeting1}" );

	// Reference Assignment
	//		hello1 is Reference to Same String Type Object At Heap
	//		hello1 Will Become Owner
	//		Ownership Moved/Shifted
	let hello1 = greeting1; // Move Symantics
	println!("Hey: {hello1}" );

	//		Hence greeting1 is Not A Valid Owner Anymore
	// println!("Hey: {greeting1}" );
	// error[E0382]: borrow of moved value: `greeting1`

	//______________________________

	let n1 = 99;
	let n2 = n1; // Copy Semantics

	println!("Values: {} {}", n1, n2 );

	// Here are some of the types that implement Copy:

	// All the integer types, such as u32.
	// The Boolean type, bool, with values true and false.
	// All the floating point types, such as f64.
	// The character type, char.
	// Tuples, if they only contain types that also implement Copy. 
	// 		For example, (i32, i32) implements Copy, 
	// 		but (i32, String) does not.

	//______________________________
	// Cloning Example

	// String Object Created In Heap
	//		some1 Is Reference To This Object
	//		some1 Is Owner Of This Object
	let some1 = String::from("H P Enterprise");
	// let some2 = some1 // Move Symatics

	// One More String Object Created In Heap
	//		some2 Will Be Reference as Well as Owner To This New Object
	let some2  = some1.clone(); // Deep Copy i.e. One More String Object Created

	println!("Value: {some1}");
	println!("Value: {some2}");	
}

//_____________________________________________________________

fn play_with_greeting( some_string: String ) {
//						ss	 ^^^^^^ this parameter takes ownership of the value
	println!("String Value: {some_string}");
	// In Case No Return Value Expresion Given At End Of Function
	//		Than It Will Return Unit Value () Of Unit Type ()
}

fn play_with_number( some_number: i32 ) {
	println!("Number Value: {some_number}");
}

fn play_with_function_parameters() {
	let greeting = String::from("Good Evening!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"
	play_with_greeting( greeting );
	// println!("After  Function Call String Value: {greeting}");

	let number = 999;
	println!("Before Function Call Number Value: {number}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Copy Symantic Is Applied Here
	play_with_number( number );
	println!("After  Function Call String Value: {number}");
}

//_____________________________________________________________

// fn play_with_greeting_once_again( some_string: String )  {
	// 					- help: try adding a return type: `-> String`

fn play_with_greeting_once_again( some_string: String ) -> String {
	println!("String Value: {some_string}");
	// some processing... logic

	// Last Expression Will Become Return Value Of The Function
	//		In Addition To Returning Value We Are Moving/Shifting Ownership
	some_string // Expression 
}

fn say_greeting() -> String {
	let greeting = String::from("Guten Tag!!!");
	println!("String Value: {greeting}");

	greeting // Expression It's Return Value As Well As Move Ownership
}


fn play_with_function_parameters_again() {
	let greeting = String::from("Good Evening!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"

	// Following greeting Takes Ownership Of Returned Value
	let greeting = play_with_greeting_once_again( greeting );
	println!("After  Function Call String Value: {:?}", greeting);

	let greet = say_greeting();
	println!("String Value: {greet}");
}


//_____________________________________________________________

//Function Parameter Takes Reference As Argument
fn calculate_length( some_string : &String ) -> usize {

	// some_string = &String::from("Changing String Value");
	// 		^ cannot assign to immutable argument
	some_string.len()
}

fn play_with_passing_references() {
	// Ownership Of This String Object Lies With greeting
	let greeting = String::from("Good Evening!!!");

	println!("String Value: {greeting}");
	
	// Borrow Semantics
	//		Passing Reference Of greeting
	//		Ownership Is Not Moved/Shifted

	// Passing Reference Of The Object Whose Ownership Lies With Someone Else
	//		greeting Have Ownership
	// 			Ownership Is Not Shifted
	//			Passing Reference Only But Not Shifting Ownership
	//		&greeting Reference Is A Safe Pointer

	let length = calculate_length( &greeting );
	// Ownership Of This String Object Lies With greeting

	println!("String Value: {greeting}");
	println!("String Length: {length}");

	let greeting1 = String::from("Good Evening!!!");

	println!("String Value: {greeting1}");
	let _reference = &greeting1; // Borrow Semantics
	println!("String Value: {greeting1}");

}

//______________________________________________________________

 // Instead, we can provide a Rust reference to the String value. 
 //     A Rust reference is like a pointer in that it’s an address 
 //		we can follow to access the data stored at that address; 
 //     that data is owned by some other variable. 
 
 //    	UNLIKE a Pointer, a reference is guaranteed to point 
 //     to a valid value of a particular type for the life of 
 //     that reference.

//______________________________________________________________

// When functions have references as parameters instead 
//      of the actual values, we won’t need to return 
//      the values in order to give back ownership, 
//      because we never had shifted ownership.

// We call the action of creating a reference borrowing. 

//_____________________________________________________________

// In Rust Be Default
// Function Arguments Are Immutable
fn change_function( mut some_string: &str ) -> String {
	println!("Inside Function Value Before: {some_string}");	
	some_string = "How are you doing?";
	
	println!("Inside function Value After: {some_string}");

	some_string.to_string()
}

fn change_function_again( mut some_string: String ) -> String {
	println!("Inside Function Value Before: {some_string}");	
	some_string.push_str( " Gentlman! " ) ;
	
	println!("Inside function Value After: {some_string}");
	some_string
}

//	Agruments Are Mutable Means 
//		Programmer Specifying This Function Can Create Side Effects
//		Mutability Through Reference
//			Require mut Keyword All Three Location
//			Function Signature, Call Location and At Variable Definition

// fn change_function_once_again( some_string: &String ) {
fn change_function_once_again( some_string: &mut String ) {
	println!("Inside Function Value Before: {some_string}");	
	some_string.push_str( " Gentlman! " ) ;	
	println!("Inside function Value After: {some_string}");
}


fn play_with_change_data() {
	let hello = "Hellooooo!!!";

	println!("Value Before: {hello}");
	let hello = change_function( hello ); // Copy Semantics
	println!("Value After : {hello}");	

	//________________________________
	let greeting = String::from("Good Morning!!!");

	println!("Value After : {greeting}");	
	let greeting = change_function_again( greeting ); // Move Semantics
	println!("Value After : {greeting}");	

	//________________________________
	// let some_string = String::from("Good Morning!!!");
	let mut some_string = String::from("Good Morning!!!");

	println!("Value After : {some_string}");	
	// let greeting = change_function_once_again( &some_string ); // Borrows Semantics
	change_function_once_again( &mut some_string ); // Borrows Semantics
	println!("Value After : {some_string}");	
}


//_____________________________________________________________

fn play_with_mutable_references() {
	let mut s = String::from("Hello!");

	let r1 = &mut s;
	println!("Value : {}", r1);

	// let r2 = &mut s;
	// println!("Value : {} {}", r1, r2);

// 290 |     let r1 = &mut s;
//     |              ------ first mutable borrow occurs here
// 291 |     let r2 = &mut s;
//     |              ^^^^^^ second mutable borrow occurs here

	//Mutable references have one big restriction: 
    // 	if you have a mutable reference to a value
    //  It Must Be Only One Mutable Reference

    // let mut ss = String::from("Hello!!!");
	// warning: variable does not need to be mutable
 
    let ss = String::from("Hello!!!");
    let r1 = &ss;
    let r2 = &ss;
    let r3 = &ss;
    // let r4 = &mut ss;
	// println!("Value : {} {} {}", r1, r2, r3, r4);
	println!("Value : {} {} {}", r1, r2, r3);

	// The restriction preventing multiple mutable references 
	//		to the same data at the same time allows for mutation 
	//		but in a very controlled fashion. 

	// The restriction preventing multiple mutable references 
	//		to the same data at the same time allows for mutation 
	//		but in a very controlled fashion. 

	// A data race is similar to a race condition and 
	//			happens when these three behaviors occur:
			//  1. Two or more pointers access the same data at the same time.
			//  2. At least one of the pointers is being used to write to the data.
			//  3. There’s no mechanism being used to synchronize access to the data.

    let mut sss = String::from("Hello!!!");
	// warning: variable does not need to be mutable
    let r1 = &sss;
    let r2 = &sss;
    let r3 = &sss;

	println!("Value : {} {} {}", r1, r2, r3);

    // The ability of the compiler to tell that a reference is no 
    // longer being used at a point before the end of the scope 
    //	is called Non-Lexical Lifetimes (NLL for short), 

    let r4 = &mut sss;
    println!("Value: {}", r4)
}

//_____________________________________________________________

/*
// error[E0106]: missing lifetime specifier
fn dangle_poiner() -> &String {
//	error[E0106]: missing lifetime specifier

	let hello = "Good Afternoon!!!";

	// Returning Reference 
	//		Changing Visibility Of Local Scope Variable
	//		Local Scope Variable Lifetime Time Ties With Scope
	return &hello
}
*/

fn dangle_poiner() -> String {
	let hello = String::from("Good Afternoon!!!");

	return hello
}

fn play_with_dangling() {
	let value = dangle_poiner();

	println!("Value : {value}")
}

// Dangling References
// 		In languages with pointers, it’s easy to erroneously 
//		create a dangling pointer--a pointer that references a 
//		location in memory that may have been given to someone else
//		--by freeing some memory while preserving a pointer to that memory. 

// IN RUST LANGUAGE
//		by contrast, the compiler guarantees that references 
//		will never be dangling references: if you have a reference 
//		to some data, the compiler will ensure that the data will 
//		not go out of scope before the reference to the data does.


//______________________________________________________________

// The Rules of References
// 		1.	At any given time, you can have either one mutable reference 
// 		2. 	or any number of immutable references.
// 		3.	References must always be valid.


//_____________________________________________________________
//
// SLICES IN RUST
//_____________________________________________________________



//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\nFunction : play_with_scope");
	play_with_scope();

	println!("\nFunction : play_with_scope_again");
	play_with_scope_again();

	println!("\nFunction : play_with_function_parameters");
	play_with_function_parameters();

	println!("\nFunction : play_with_function_parameters_again");
	play_with_function_parameters_again();

	println!("\nFunction : play_with_passing_references");
	play_with_passing_references();

	println!("\nFunction : play_with_change_data");
	play_with_change_data();

	println!("\nFunction : play_with_mutable_references");
	play_with_mutable_references();

	println!("\nFunction : play_with_dangling");
	play_with_dangling();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}


