
_____________________________________________________________________

DAY 01
_____________________________________________________________________

ENVIRONMENT SETUP
	Please Setup Rust Programming Compilers

REVISION ASSIGNMENT:
	Practice Code Examples Done Till Now In Class

READING ASSIGNMENT:
	Chapter 02: Types, Operators and Expressions
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie

RUST READING MATERIAL:
	Reference Book:
		Rust Book https://doc.rust-lang.org/stable/book/

	Reading Assignment:
		https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
		https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html
			Variables and Mutability
			Data Types
			Functions
			Control Flows
_____________________________________________________________________

DAY 02
_____________________________________________________________________

REVISION ASSIGNMENT:
	Practice Code Examples Done Till Now In Class

RUST READING MATERIAL:
	Reference Book:
		Rust Book https://doc.rust-lang.org/stable/book/

		https://doc.rust-lang.org/book/ch04-00-understanding-ownership.html
		
_____________________________________________________________________

DAY 03
_____________________________________________________________________

REVISION ASSIGNMENT:
	Practice Code Examples Done Till Now In Class

RUST READING MATERIAL:
	Reference Book:
		Rust Book https://doc.rust-lang.org/stable/book/

		https://doc.rust-lang.org/book/ch05-00-structs.html
		https://doc.rust-lang.org/book/ch06-00-enums.html
		https://doc.rust-lang.org/book/ch07-00-managing-growing-projects-with-packages-crates-and-modules.html
		https://doc.rust-lang.org/book/ch08-00-common-collections.html
		https://doc.rust-lang.org/book/ch09-00-error-handling.html
		https://doc.rust-lang.org/book/ch10-00-generics.html
		
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
