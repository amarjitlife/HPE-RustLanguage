#![allow(unused)]

use std::fmt;
use std::fmt::Display;
use std::fmt::Debug;

//______________________________________________________________

fn largest_i32( list: &[i32] ) -> &i32 {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn largest_char(list: &[char]) -> &char {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn play_with_largest() {
    let number_list = vec![34, 50, 25, 100, 65];

    let result = largest_i32(&number_list);
    println!("The largest number is {result}");

    let char_list = vec!['y', 'm', 'a', 'q'];

    let result = largest_char(&char_list);
    println!("The largest char is {result}");
}

//_____________________________________________________________

// Generic Function
//		Polymorphic Function
//		Compile Time Polymorphism
fn largest<T : std::cmp::PartialOrd>( list: &[T] ) -> &T {
	let mut largest = &list[0];

	for item in list {
		if item > largest {
			largest = item;
		}
	}
	largest
}

fn play_with_largest_generic() {
	let numbers = vec![10, 20, 40, 10, 100, 99, 65];
	let result = largest( &numbers );

	println!("The Largest Number: {}", result);

	let characters = vec!['Y', 'A', 'a', 'm', 'q', 'B'];
	let result = largest( &characters );
	println!("The Largest Number: {}", result);
}

//_____________________________________________________________
// Generic Structure

#[derive(Debug)]
struct  Point<T> {
	x: T,
	y: T,
}


fn play_with_point_generic() {
	let integer_point = Point { x : 10, y: 20 };
	let float_point = Point{ x: 10.10, y: 20.3 };
}

//_____________________________________________________________

#[derive(Debug)]
struct  Point1<T, U> {
	x: T,
	y: U,
}

fn play_with_point_generic1() {
	let integer_point = Point1 { x : 10, y: 20 };
	let float_point = Point1 { x: 10.10, y: 20.3 };
	let integer_float_point = Point1 { x: 999, y: 20.3 };
}

//_____________________________________________________________

#[derive(Debug)]
struct  Point2<T> {
	x: T,
	y: T,
}

impl<T> Point2<T> {
	// Generic Method
	fn x(&self) -> &T {
		&self.x
	}
}

impl Point2<f32> {
	// Generic Method
	fn distance_from_origin(&self) -> f32 {
		(self.x.powi(2) + self.y.powi(2)).sqrt()
	}
}

fn play_with_point_generic2() {
	let integer_point = Point2 { x : 10, y: 20 };
	let float_point = Point2 { x: 10.10, y: 20.3 };

	integer_point.x ;
	integer_point.x();


}

//______________________________________________________________

struct Point3<X1, Y1> {
    x: X1,
    y: Y1,
}

impl<X1, Y1> Point3<X1, Y1> {

    fn mixup<X2, Y2>(self, other: Point3<X2, Y2>) -> Point3<X1, Y2> {
        Point3 {
            x: self.x,
            y: other.y,
        }
    }
}

fn play_with_point_generic3() {
    let p1 = Point3 { x: 5, y: 10.4 };
    let p2 = Point3 { x: "Hello", y: 'c' };

    let p3 = p1.mixup(p2);

    println!("p3.x = {}, p3.y = {}", p3.x, p3.y);
}

//______________________________________________________________
// Generic Enums

enum Option<T> {
    Some(T),
    None,
}

enum Result<T, E> {
    Ok(T),
    Err(E),
}

//_____________________________________________________________
//   TRAITS

trait Summary {
	fn summarize( &self ) -> String;
}

struct NewsArticle {
	headline: String,
	location: String,
	author: String,
	content: String,
}

impl Summary for NewsArticle {
	fn summarize( &self ) -> String {
		format!("{}, by {} {}", self.headline,
			self.author, self.location)
	}
}

impl Display for NewsArticle {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        // Write strictly the first element into the supplied output
        // stream: `f`. Returns `fmt::Result` which indicates whether the
        // operation succeeded or failed. Note that `write!` uses syntax which
        // is very similar to `println!`.
        write!(f, "{}", self.headline)
    }
}

struct Tweet {
	username: String,
	content: String,
	reply: bool,
	retweet: bool,
}

impl Summary for Tweet {
	fn summarize( &self ) -> String {
		format!("{}: {}", self.username, self.content)
	}
}

// Polymorphic Function
fn notify( item: &impl Summary ) {
	println!("Breaking News! {}", item.summarize() );
}

// Polymorphic Function
fn notify_again<T : Summary>( item: &T ) {
    println!("Breaking news! {}", item.summarize());
}

fn notify2(item1: &impl Summary, item2: &impl Summary) {

}

fn notify3( item: &(impl Summary + Display)) {

}

fn notify3_again<T: Summary + Display>(item: &T) {

}


fn play_with_traits() {
	let article = NewsArticle {
		headline: "String...".to_string(),
		location: "String...".to_string(),
		author: "String...".to_string(),
		content: "String...".to_string(),		
	};

	let tweet = Tweet {
		username: "Gabbar Singh".to_string(),
		content: "How are you doing?".to_string(),
		reply: true,
		retweet: true,
	};

	let result = article.summarize();
	println!("Result: {result}");

	tweet.summarize();
	println!("Result: {result}");
}


// Following Display Trait Comes From std::fmt::Display
// pub trait Display {
//     // Required method
//     fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), Error>;
// }

// REFERENCE LINK: https://doc.rust-lang.org/std/fmt/trait.Display.html


//______________________________________________________________
// Following Both Are Equivalent

fn some_function<T: Display + Clone, U: Clone + Debug>( t: &T, u: &U ) -> i32 
{
    99
}

// Far More Readable Syntax
fn some_function_again<T, U>(t: &T, u: &U) -> i32
where
    T: Display + Clone,
    U: Clone + Debug,
{
    99
}

//______________________________________________________________

// use std::fmt::Display;

struct Pair<T> {
    x: T,
    y: T,
}

impl<T> Pair<T> {
    fn new(x: T, y: T) -> Self {
        Self { x, y }
    }
}

impl<T: Display + PartialOrd> Pair<T> {
    fn cmp_display(&self) {
        if self.x >= self.y {
            println!("The largest member is x = {}", self.x);
        } else {
            println!("The largest member is y = {}", self.y);
        }
    }
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________


fn main() {
	println!("\nFunction : play_with_largest_generic");
	play_with_largest_generic();

	println!("\nFunction : play_with_point_generic");
	play_with_point_generic();

	println!("\nFunction : play_with_point_generic1");
	play_with_point_generic1();

	println!("\nFunction : play_with_point_generic2");
	play_with_point_generic2();

	println!("\nFunction : play_with_traits");
	play_with_traits();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}

