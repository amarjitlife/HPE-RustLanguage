
//_____________________________________________________________
//
// SLICES IN RUST
//_____________________________________________________________


fn play_with_slices() {
	let s: String = String::from("Hello World!");

	let len = s.len();

	// Slice From String
	// 		Slice :: [ start_index..end_index ]
	// 		start_index Is 0 By Default
	// 		end_index Is Len By Default

	let hello = &s[0..5];
	let world = &s[6..11];

	println!("Value: {s} Length: {len}");
	println!("Value: {hello}");
	println!("Value: {world}");

	let hello1: &str = &s[0..5];
	let world1: &str = &s[6..11];

	println!("Value: {s} Length: {len}");
	println!("Value: {hello1}");
	println!("Value: {world1}");

	let slice = &s[0..2];
	println!("Value: {slice}");
	let slice = &s[..2];
	println!("Value: {slice}");

	let slice = &s[3..len];
	println!("Value: {slice}");
	let slice = &s[3..];
	println!("Value: {slice}");

    let ss = "Hello World!😊♥";
    let len = ss.len();
	println!("Value: {ss} Length: {len}");

    // The type of ss here is &str : it’s a slice pointing to that 
    // specific point of the binary. This is also why string literals 
    // are immutable; &str is an immutable reference.
}

//_____________________________________________________________


fn first_word_better( s: &String ) -> &str {
	let bytes = s.as_bytes();
	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}
	// s.len()
	&s[..]
}

fn play_with_first_word_better() {
	let sentence = String::from("How Are You Doing?");
	// let mut sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word_better( &sentence );
	println!("Result : {word}");

	// sentence.clear();
	// println!("Sentence : {sentence}");
}

//_____________________________________________________________


fn first_word_better( s: &str ) -> &str {
	let bytes = s.as_bytes();
	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}
	// s.len()
	&s[..]
}

fn play_with_first_word_better() {
	let sentence = String::from("How Are You Doing?");
	// let mut sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word_better( &sentence );
	println!("Result : {word}");

	// sentence.clear();
	// println!("Sentence : {sentence}");
}

//_____________________________________________________________

fn printing_byte_buffer( s: &str ) {
	let bytes = s.as_bytes();
	for byte in bytes {
		println!(" {byte} ");
	}
}

fn play_with_printing_byte_buffer() {
	// let sentence = String::from("How Are You Doing?");

	let sentence = String::from("How Are You Doing?😊");
	// let mut sentence = String::from("How Are You Doing?");

	printing_byte_buffer( &sentence );
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\nFunction : play_with_slices");
	play_with_slices();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}


