//_____________________________________________________________

use std::io;

//_____________________________________________________________

/*
// In Unix/Linux/Mac OSX
1. Save Code in Hello.rs
2. Make Directory Current In Which You Save Hello.rs
3. To Compile
		rustc Hello.rs
		It Will Generate Hello Executable

		rustc Hello.rs -o hello
4. To Run
		./Hello
*/

//_____________________________________________________________

fn hello_world() {
	println!("Hello World!!!");
	println!("Welcome to Rust Programming");
}

//_____________________________________________________________

// Design Principle
//		Design Towards Immutability Rather Than Mutablity
//		Design Towards Explicit Programming Rather Than Implicit Programming

fn play_with_mutability() {
	// What is the Data Type?
	// 1. Type Inferencing Will Happen From RHS Value
	// 2. Type Binding : Inferred Type is Binded With LHS Value
	let number = 10; // 

	println!("Value : {number}");
	// number = 999; // cannot assign twice to immutable variable `number`
	println!("Value : {number}");	

/*
	// let mut numberAgain = 10; // warning: variable `numberAgain` should have a snake case name
	println!("Value : {numberAgain}");
	numberAgain = 999;
	println!("Value : {numberAgain}");
*/

	// What is the Data Type?
	// 1. Type Inferencing Will Happen From RHS Value
	// 2. Type Binding : Inferred Type is Binded With LHS Value

	#[allow(unused_variables)] // To Be Used In Rarest Rare Scenarios
	let condition = true; // Type Inferred Bool and Binded Type Bool
	// condition = "Hello"; // error[E0308]: mismatched types
}

//_____________________________________________________________

fn play_with_if_else() {
	// What is the Data Type?
	// 1. Type Inferencing Will Happen From RHS Value
	// 2. Type Binding : Inferred Type is Binded With LHS Value

	let condition = true;

	// if-else Is An Expression
	let number = if condition { 50 } else { 60 };
	// let number = if condition { 50 } else { "Hello" };
	// error[E0308]: `if` and `else` have incompatible types

	println!("Value: {number}");


	let number_again = if condition { 
		let _ = 5 + 10 ; 	// Statement
		// 200
		let x = 100 + 200; 	// Statement 
		x + 300 + 900 		// Expression
		// 10
		// let _ = 99 ;
	} else { 		
		let _ = 6 - 10 ; // _ Is Name Of Variable To Ignore It 
		111 + 222 	// Expression
	};	

	println!("Value: {number_again}");


	let x = -10;
	// In C/C++/Java/Python
	// 		Here expression Can Be Anthing Which Evaluates To int Value
	//		Non-Zero Treated As True and Zero Value Treated As False
	// if( expression ) {  }  else {  }

	// In Rust
	//		expression Evaluates To Bool
	//	if expression

	let something = if x == 10 { 		
		println!("If Branch Executed");
	} else {
		println!("Else Branch Executed");		
		// 999 // Error: ^^^ expected `()`, found integer
	};

	println!("Value something = {:?}", something);

	let xx = 99;
	let something_again = if xx == 10 { 		
		println!("If Branch Executed");
	} else {
		println!("Else Branch Executed");		
	};

	// What Will Be Value of something_again
	println!("Value something_again = {:?}", something_again );

// Else Branch Executed
// Value something = ()
// Else Branch Executed
// Value something_again = ()

// In Rust
//		() Means Unit Value of Unit Type ()

}

//_____________________________________________________________


// 15 Mintues Break After That We Will Continue

//_____________________________________________________________

fn play_with_shadowing() {

	let guess = "Good Evening!!!";
	println!("Value: {guess}");

//	Shadowing Previous Defintion
	let guess = "Guten Tag!!!";
	println!("Value: {guess}");

//	Shadowing Previous Defintion
	let guess = 99 ;
	println!("Value: {guess}");

	// Immutable
	let greeting = "Good Good Afternoon!!!";
	println!("Value: {greeting}");

	// somewhere in code want to change the value
	// Mutability Should Be As Local As Possible
	let mut greeting = "Good Afternoon!!!";
	println!("Value: {greeting}");

	greeting = "Goooooodd!!!";
	println!("Value: {greeting}");

	// Shadowing Previous Definition
	let greeting = "Good Good Afternoon!!!";
	println!("Value: {greeting}");

	// greeting = "do something else..."; // cannot assign twice to immutable variable
	println!("Value: {greeting}");

	// Outside Context
	let x = 5;
	let x = x + 1;

	// Inside Context
	{
		// Inside Context Always Supercede Outside Context
		let x = x * 2;
		println!("Value: {x}")
	}

}

//	SYSTEM PRINCIPLE
//		PREDICTABLE AND PROVABLE

// 	DESIGN PRINCIPLE
//		 Design Towards IMMutability Rather Than Towards Mutability

// In C/C++/Java/Python
//		Mutability Is Default
// 		int a = 100;
// 		a = 100

//		String greeting = new String(); // greeting is Mutable By Default

// In Rust
//		IMMutability Is Default


// Static Languages
//		C/C++/Java/Rust
//		Most Of The Decisions Are Done At Compile Time
//		Happens At Compile Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable

// Dynamic Languages
//		Python/Ruby/Objective-C/JavaScript
//		Most Of The Decisions Are Done At Run Time
//		Happens At Run Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable


//_____________________________________________________________

// unsafe fn play_with_static() {

#[allow(static_mut_refs)]
fn play_with_static() {
	// error: missing type for `static` item
	// static something = 99;

	// static something: i32 = 99;
	// warning: static variable `something` should have an upper case name	
	// println!("Value {something}");

	unsafe {
		static mut SOMETHING: i32 = 99;
		// error[E0133]: use of mutable static is unsafe and 
		//		requires unsafe function or block
		println!("Value {SOMETHING}");
	}

	{
		static SOMETHING: i32 = 99;
		println!("Value {SOMETHING}");
	}

	// SOMETHING = 100;
	// println!("Value {SOMETHING}");
}



//_____________________________________________________________
/*
// In C/C++
int a = 10;
char ch = 'A';

// In Java
int a = 10;
char ch = 'A';
*/

//_____________________________________________________________

// Primitives
// Rust provides access to a wide variety of primitives. A sample includes:

// Every value in Rust is of a certain data type, 
// which tells Rust what kind of data is being specified so 
// it knows how to work with that data. We’ll look at two 

// data type subsets: scalar and compound.

// Scalar Types
// Signed integers: i8, i16, i32, i64, i128 and isize (pointer size)
// Unsigned integers: u8, u16, u32, u64, u128 and usize (pointer size)
// Floating point: f32, f64
// char Unicode scalar values like 'a', 'α' and '∞' (4 bytes each)
// bool either true or false
// The unit type (), whose only possible value is an empty tuple: ()
// Despite the value of a unit type being a tuple, 
//		it is not considered a compound type because 
//		it does not contain multiple values.



// Compound Types
// Arrays like [1, 2, 3]
// Tuples like (1, true)



// Table 3-1: Integer Types in Rust
// Length	Signed	Unsigned 	Memory
// 8-bit	i8		u8 			1
// 16-bit	i16		u16 		2
// 32-bit	i32		u32 		4
// 64-bit	i64		u64			8
// 128-bit	i128	u128		16

// arch		isize	usize


// NOTE :: IMPORTANT
// So how do you know which type of integer to use? 
// If you’re unsure, 

// Rust’s defaults are generally good places to start: 
// 		integer types default to i32.
//		The primary situation in which you’d use isize or usize 
//		is when indexing some sort of collection.


// Table 3-2: Integer Literals in Rust

// Number literals	Example
// Decimal			98_222
// Hex				0xff
// Octal			0o77
// Binary			0b1111_0000
// Byte (u8 only)	b'A'

//_____________________________________________________________


#[allow(unused)]
fn play_with_types() {
    // In C/C++/Java By Default It's double Type
    // In Rust double is Equivalent to f64
    let x = 98.98; //f64

    // Explicitly Annotating To Make It f32
    let y: f32 = 3.0; // f32

    // addition
    let sum = 5 + 10; // i64

    // subtraction
    let difference = 95.5 - 4.3;

    // multiplication
    let product = 4 * 30;

    // division
    let quotient = 56.7 / 32.2;
    let truncated = -5 / 3; // Results in -1

    // remainder
    let remainder = 43 % 5;

    // Rust char Type Is Unicode Character Type
    // In C/C++ char Is ASCII Character

	let c = 'z';
	// Type Explicitly Annotated
	let z: char = 'Z';
	let zz: char = '😊';

	println!("Value: {c}" );
	println!("Value: {z}" );
	println!("Value: {zz}" );

	// Tuple: Associated Types

	let mut tup1 = (100, 90.90, 1);
	let tup2 = (100, 80.80, 1);

	let (x, y, z) = tup1;
	println!("Value: {x} {y} {z}");
	tup1 = tup2;

	let (x, y, z) = tup1;	
	println!("Value: {x} {y} {z}");

// In Python
	// let t1 = tup1[0];

	let t1 = tup1.0;
	let t2 = tup1.1;
	let t3 = tup1.2;

	println!("Value: {t1} {t2} {t3}");

	let tup3 = (100, 80.80, 9.9);
	// tup1 = tup3;
	// 	expected `({integer}, {float}, {integer})`, 
	//	found `({integer}, {float}, {float})`

	// let (x, y, z) = tup1;	
	// println!("Value: {x} {y} {z}");

	let tup5: (i64, f64, i64) = (100, 89.89, 1);
	let tup6: (i32, f64, u8) = (100, 89.89, 1);

	let xx: i32 = 90;
	let yy: i64 = 100;

	// let zz = xx + yy; // 	// error[E0308]: mismatched types
	// let zz: i64 = xx + yy;  	// error[E0308]: mismatched types

	let zz: i64 = xx as i64 + yy;
	println!("Value {zz}");

	// error[E0308]: mismatched types
	// 	you can convert an `i64` to an `i32` and 
	//	panic if the converted value doesn't fit
	// let zz: i32 = xx as i64 + yy; 
	// println!("Value {zz}");
}

//_____________________________________________________________

/*
Lunch Break For 1 Hour
Lunch Break Given At 11:40 PM IST (Indian Standard Time)
We Will Meet At 12:40 PM IST
*/

//_____________________________________________________________

/*

	EXPERIMENT CODE AND COMPLETE HANDS ON! 
	RAISE YOUR HAND MOMENT DONE!

		1. Walkthrough Code Examples Already Done!
			https://codeshare.io/5OEEVv			
		
		2. Practice Code Examples
		
		3. Read Commentary on Code Examples

*/

//_____________________________________________________________

fn play_with_array() {
	// Inferred and Binded Type : [i32 ; 5 ]
	let a = [10, 20, 30, 40, 50 ];

	let _first	= a[0];
	let _second = a[1];

	let mut data = String::new();

	io::stdin()
		.read_line( &mut data )
		.expect("Failed To Read File");

	let index: usize = data
		.trim()
		.parse()
		.expect("Index Is Not A Number");

	let element = a[index];

	println!("Value: {} at Index: {}", element, index );

	// let _some_element = a[8];
	//^^^^ index out of bounds: the length is 5 but the index is 8

	// Type Annotation
	// Explicitly Annotating Type
	let aa: [ i32 ; 5 ] = [ 10, 20, 30, 40, 50 ];
	
	let _aaa = [ 10, 20, 30, 40, 50 ]; // Inferred Type

	println!("Array {:?} ", aa);

	// BEST PRACTICE
	//		Always Prefer for-in Loop Over Indexing Loop
	for element in a { 
		println!("Array a: {}", element);
	}

	let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun" ];
	for element in months {
		println!("Array a: {}", element )
	}

 	let mut counter = 0;
 	let _result = loop {
 		counter += 1;
 		if counter == 10 {
 			break counter * 2;
 		}
 	};

 	// let _bb = [10, 20, 30, "Ding", "Dong", 99.99]; 
 	// error[E0308]: mismatched types
}


//_____________________________________________________________

// The Rust
// compiler guarantees that when you state a value won’t change, 
// it really won’t change, so youdon’t have to keep track of it yourself. 

// Constants
// Like immutable variables, constants are values that are bound to a name and are not allowed
// to change, but there are a few diﬀerences between constants and variables.
// First, you aren’t allowed to use mut with constants. Constants aren’t just immutable by
// default—they’re always immutable. You declare constants using the const keyword instead
// of the let keyword, and the type of the value must be annotated.

// Shadowing
// you can declare a new variable with
// the same name as a previous variable. Rustaceans say that the first variable is shadowed by
// the second, which means that the second variable is what the compiler will see when you
// use the name of the variable. In eﬀect, the second variable overshadows the first, taking any
// uses of the variable name to itself until either it itself is shadowed or the scope ends. We can
// shadow a variable by using the same variable’s name and repeating the use of the let
// keyword

//_____________________________________________________________

// In Rust
//		By default Functions In Rust Returns Unit Value of Unit Type
fn function_with_one_arguments( x: i32 ) {
	println!("\nFunction With One Arguemnt Called: {x}")
}

fn function_with_two_arguments( x: i32, y: f64 ) {
	println!("\nFunction With Two Arguemnt Called: {x} {y}")
}

fn some_function() -> i32 {
	let x = 77; // Statement
	println!("Some Function Called..."); // Statement
	// In Rust
	//		If You Specify Last Expression 
	//		Than Expression Value Will Be Return Value of Function
	x // Expression
}

fn play_with_functions() {
	function_with_one_arguments( 100 );
	function_with_two_arguments( 999, 22.22 );

	let result = some_function();
	println!("Result : {result}" );

	let result_again = function_with_one_arguments( 99 );
	println!("Result Again: {:?}", result_again );
}

//_____________________________________________________________

// Rust is a statically typed language, which means that it must know the
// types of all variables at compile time. The compiler can usually infer 
// what type we want to use based on the value and how we use it.

//_____________________________________________________________

fn play_with_loop() {
	let mut count = 0;

	'counting_up: loop {
		println!("Count : {count}");
		let mut remaining = 10;

		loop {
			println!("Remaining : {remaining}");
		
			if remaining == 9 {
				break;
			}

			if count == 2 {
				break 'counting_up;
			}
			remaining -= 1;
		}
		count += 1;
	}
	println!("End Count: {count}");

	let mut number = 3;
	while number != 0 {
		println!("{number}");
		number -= 1
	}
}


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\nFunction : ");
	hello_world();

	println!("\nFunction : play_with_mutability");
	play_with_mutability();

	println!("\nFunction : play_with_if_else");
	play_with_if_else();

	println!("\nFunction : play_with_shadowing");
	play_with_shadowing();

	println!("\nFunction : play_with_static");
	play_with_static();

	println!("\nFunction : play_with_types");
	play_with_types();

	println!("\nFunction : play_with_array");
	play_with_array();

	println!("\nFunction : play_with_functions");
	play_with_functions();

	println!("\nFunction : play_with_loop");
	play_with_loop();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");	
}


