

//_____________________________________________________________

fn play_with_constants() {
	const THREE_HOURS_IN_SECONDS: u32 = 60 * 60 * 3;

	// const THREE_HOURS_IN_SECONDS: u32 = 60 * 60 * 3;
	// error[E0428]: the name `THREE_HOURS_IN_SECONDS` is defined multiple times


}

// Constants
// Like immutable variables, constants are values that are bound to a name and are not allowed
// to change, but there are a few diﬀerences between constants and variables.
// First, you aren’t allowed to use mut with constants. Constants aren’t just immutable by
// default—they’re always immutable. You declare constants using the const keyword instead
// of the let keyword, and the type of the value must be annotated. 

// Just know that you must always annotate the type.
// Constants can be declared in any scope, including the global scope,

// The last diﬀerence is that constants may be set only to a constant expression, 
// not the result of a value that could only be computed at runtime.

// Statements and Expressions
// Function bodies are made up of a series of statements optionally ending in an expression.
// Because Rust is an expression-based language,
// this is an important distinction to understand. Other languages don’t have the same
// distinctions


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\nFunction : play_with_constants");
	play_with_constants();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}


