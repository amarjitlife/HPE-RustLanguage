
#include <stdio.h>

//_______________________________________________

// void authentication( username, password ) {
	// username = "default;
	// password = "dfdfdfdfd";

void playWithArrays() {
	// 0 to 4
	int a[5] = { 10, 20, 30, 40, 50 };
	int * ptr = a;

	for ( int i = -3 ; i < 10; i ++ ) {
		printf("\n Value: %d", *(ptr + i) );
	}
	
	// if ( MIN_INDEX < index < MAX_INDEX )
	int some_element = a[9];
	printf("\n Value: %d ", some_element);

	some_element = a[ -5 ];
	printf("\n Value: %d ", some_element);
}

//_______________________________________________
// Choices Are: 20, 30, 80, RTE, CTE, None Of These

void doChange1( int * ptr ) {
	int b = 30;
	ptr = &b;
	b = b + 50;
}

void playWithDoChange1() {
	int a = 20;
	int * ptr = &a;
	doChange1( ptr );
	printf("\nValue: %d", a);
}

//___________________________________

void doChange2( int * ptr ) {
	int b = 30;
	ptr = &b;
	b = b + 50;
}

void playWithDoChange2() {
	int a = 20;
	int * ptr = &a;
	doChange2( ptr );
	printf("\nValue: %d", *ptr );
}

//___________________________________

int * doChange3( int * ptr ) { // Dead Context
	int b = 30;
	ptr = &b;
	b = b + 50;

	return ptr;
}

void playWithDoChange3() {
	int a = 20;
	int * ptr = &a;
	
	// ptr contains Address Of b In Dead Context
	// 	 	Dangling Pointer 
	ptr = doChange3( ptr );

	printf("\nValue: %d", *ptr );
}


//_______________________________________________

// Function Can Return Only 1 Value
//		Either Return Valid Result Or Error Code
int sum(int a, int b, int *result) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        return 0; // overflow or underflow
    }
    
    *result = a + b;
    return 1; // success
}

int sum(int a, int b, int *error) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        *error = 0; // overflow or underflow
    }
    
    int result = a + b;
    *error = 0;
    return result; 
}

//_______________________________________________

struct Result {
	int value;
	int valid;
}

Result sum(int a, int b) {  
	Result result;
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        result.valid = 0; // overflow or underflow
    }
    
    result.value = a + b;
    result.valid = 1;
    return result; 
}

//_______________________________________________

struct Option {
	int value;
	int valid;
}

Option sum(int a, int b) {  
	Option result;
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        result.valid = 0; // overflow or underflow
    }
    
    result.value = a + b;
    result.valid = 1;
    return result; 
}

//_______________________________________________
//_______________________________________________

void main() {
	printf("\nFunction: playWithArrays");
	playWithArrays();

	printf("\nFunction: playWithDoChange1");
	playWithDoChange1();

	printf("\nFunction: playWithDoChange2");
	playWithDoChange2();

	printf("\nFunction: playWithDoChange3");
	playWithDoChange3();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}

