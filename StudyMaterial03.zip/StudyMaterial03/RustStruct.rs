

//_____________________________________________________________

// In Rust

// Associative Types
// 	Tuple
// 	Structure


// A struct, or structure, is a custom data type that lets you 
// package together and name multiple related values that make up a meaningful group

// Structure Members Are Called fields, attribute

// Structure and Tuple in that both hold multiple related values. 
// Like tuples, the pieces of a struct can be different types. 
// Unlike with tuples, in a struct you’ll name each piece of data 
// so it’s clear what the values mean.


//_____________________________________________________________

struct User {
	active: bool,
	username: String,
	email: String,
	sign_in_count: u64,
}

fn play_with_user() {
	let user = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!(" user: {} {} {} {}", user.active, user.username, 
		user.email, user.sign_in_count);

	let mut user1 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!(" user1: {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count);

	user1.email = "rockstar@yahoo.com".to_string();

	println!(" user1: {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count);

	let user2 = User {
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		active: true,
		sign_in_count: 1,
	};

	println!(" user2: {} {} {} {}", user2.active, user2.username, 
		user2.email, user2.sign_in_count);


	let user3 = User {
		// username: "Rock Star",
		username: "Rock Star".to_string(),
		email: String::from("rockstar@gmail.com"),
		active: true,
		sign_in_count: 1,
	};

	println!(" user3: {} {} {} {}", user3.active, user3.username, 
		user3.email, user3.sign_in_count);


	let user4 = User {
		// username: "Rock Star",
		username: "Rock Star".to_string(),
		email: user1.email,
		active: user1.active,
		sign_in_count: user1.sign_in_count,
	};


	println!(" user4: {} {} {} {}", user4.active, user4.username, 
		user4.email, user4.sign_in_count);

	let user5 = User {
		// username: "Rock Star",
		username: "Rock Star".to_string(),
		..user2 // Assigns user2 Member Values To user5 Remaining Members
	};

	println!(" user4: {} {} {} {}", user5.active, user5.username, 
		user5.email, user5.sign_in_count);


	//______________________________

	let user3 = User {
		username: "Rock Star".to_string(),
		email: String::from("rockstar@gmail.com"),
		active: true,
		sign_in_count: 1,
	};

	let user6 = user3; // Move Semantics


	println!(" user6: {} {} {} {}", user6.active, user6.username, 
		user6.email, user6.sign_in_count);

	// println!(" user3: {} {} {} {}", user3.active, user3.username, 
	// 	user3.email, user3.sign_in_count);
	

	// IMPORTANT NOTE 
	// 		Note that the struct update syntax uses = like an assignment; 
	//		this is because it moves the data,

}

//_____________________________________________________________


fn build_user( email: String, username: String ) -> User {
	
	User {
		username: username,
		email: email,
		active: true,
		sign_in_count: 1,
	}
}

fn build_user_again( email: String, username: String ) -> User {

	User {
		// Shortcut Syntax of Initialisation
		//	 Used Wherever Function Parameter Names Are Same As Structure Field Names
		username,
		email,
		active: true,
		sign_in_count: 1,
	}
}


fn play_with_build_user() {
	let mansa = build_user( String::from("mansa@gmail.com"), String::from("Mansa Tell"));

	println!("Data : {} {} {} {}", mansa.active, mansa.username, 
		mansa.email, mansa.sign_in_count );		

	let mansa1 = build_user_again( String::from("mansa@gmail.com"), String::from("Mansa Tellis"));

	println!("Data : {} {} {} {}", mansa1.active, mansa1.username, 
		mansa1.email, mansa1.sign_in_count );		
}


//_____________________________________________________________


// Creating Rectangle Type Using Structure Construct
struct Rectangle {
	width: u32,
	height: u32,
	// center: (u32, u32),
}

// Design Choice 01
fn area( width: u32, height: u32 ) -> u32 {
	width * height
}

// Design Choice 02
fn area_better( dimension: ( u32, u32 ) ) -> u32 {
	dimension.0 * dimension.1
}

// Design Choice 03
fn area_best( rectangle: Rectangle ) -> u32 {
	rectangle.width * rectangle.height
}


fn play_with_area() {
	let width1 = 30;
	let height1 = 50;

	let result = area( width1, height1 );
	println!("Rectangle Area: {}", result );

	let rectangle_dimension = ( width1, height1 ); 
	let result = area_better( rectangle_dimension );
	println!("Rectangle Area: {}", result );

	let rectangle = Rectangle {
		width: 30,
		height: 50,
	};

	let _rectangle1: Rectangle;
	// Lot of Code///

	_rectangle1 = Rectangle {
		width: 30,
		height: 50,
		 // ^^^^^^^^^ missing `height`
		 // height,
	};

	let result = area_best( rectangle );
	println!("Rectangle Area: {}", result );
}

//_____________________________________________________________

// Using Tuple Structs without Named Fields to Create Different Types

// Rust also supports structs that look similar to tuples, called tuple structs. 
// Tuple structs have the added meaning the struct name provides 
// but don’t have names associated with their fields; rather, 
// they just have the types of the fields

// TUPLE STRUCTS
// Custom Tuple Type Using Structure
//		Named Tuple Type
struct Color(u8, u8, u8);

// Creating Custome Tuple Types
//		Point and Point3D Are Two DIFFERENT Types
struct Point( i32, i32, i32 ); 		// 3-Dimensional Point

#[allow(dead_code)]
struct Point3D( i32, i32, i32 ); 	// 3-Dimensional Point

// Structures With Member Field
#[allow(dead_code)]
struct ColorAgain {
	red: u8, 
	green: u8, 
	blue: u8,
}

#[allow(dead_code)]
struct PointAgain {
	x: i32, 
	y: i32, 
	z: i32,
} // 3-Dimentional Point


fn play_with_custom_tuple_types() {
	// Creating white Variable Of Tuple Type: (u8, u8, u8)
	let white: (u8, u8, u8) = (255, 255, 255);
	println!("Color Components RGB: {} {} {}", white.0, white.1, white.2 );

	let black 	= Color( 0, 0, 0 );
	let origin 	= Point( 0, 0, 0 );

	// let black1: (u8, u8, u8) = Color( 0, 0, 0 );
	// // ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	// let origin1: (i32, i32, i32) = Point(0, 0, 0 );
	//  // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	let black2: Color = Color( 0, 0, 0 );
	// ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	let origin2: Point = Point(0, 0, 0 );
	 // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	println!("Color Components RGB: {} {} {}", black.0, black.1, black.2 );
	println!("Coordinates x, y, z : {} {} {}", origin.0, origin.1, origin.2 );

	// println!("Color Components RGB: {} {} {}", black1.0, black1.1, black1.2 );
	// println!("Coordinates x, y, z : {} {} {}", origin1.0, origin1.1, origin1.2 );

	println!("Color Components RGB: {} {} {}", black2.0, black2.1, black2.2 );
	println!("Coordinates x, y, z : {} {} {}", origin2.0, origin2.1, origin2.2 );

	let point1: Point = Point( 10, 10, 10 );
	// let mut point1: Point = Point( 10, 10, 10 );
	// point1 = Point3D( 20, 20, 30 );
	// ^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `Point3D`
	// Because Created 
	println!("Coordinates x, y, z : {} {} {}", point1.0, point1.1, point1.2 );

	// point1 = PointAgain{ x: 30, y: 40, z: 30, };
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `PointAgain`
}

//_____________________________________________________________

// Unit-Like Structs Without Any Fields
//	You can also define structs that don’t have any fields! 
//	These are called unit-like structs because they behave similarly to ()
//	
// Unit-like structs can be useful when you need to implement a trait 
// on some type but don’t have any data that you want to store in the type itself

// Used To Create A Type
#[derive(Debug)]
struct AlwaysEqual;

fn play_with_struct_without_fields() {
	let subject: AlwaysEqual = AlwaysEqual ;

	// println!("AlwaysEqual Value: {}", subject );
	// 		error[E0277]: `AlwaysEqual` doesn't implement `std::fmt::Display`

	println!("AlwaysEqual Value: {:?}", subject );

}

//_____________________________________________________________

// METHODS - MEMBER FUNCTIONS

struct RectangleAgain {
	width: u32,
	height: u32,
}

impl RectangleAgain {
		// Associative Function - Method
	// 		Methods - Member Functions Which Takes First Argument self Of Self Type
	//		&Self means We Are Borrowing self
	fn area( self : &Self ) -> u32 {
		self.width * self.height
	}

	// Associative Function - Method
	// 		&self Is A Shortcut Syntax Of First Argument viz. self: &Self 
	fn is_width( &self ) -> bool {
		self.width > 0
	}

	// Associative Function - Method
	// 		&self Is A Shortcut Syntax Of First Argument viz. self: &Self
	// 		Method Taking More Than 1 Arugment
	fn can_hold( &self, other: &RectangleAgain ) -> bool {
		self.width > other.width && self.height > other.height
	}	

	// Associative Function
	// 		Associated functions that aren’t methods are often used for 
	//		constructors that will return a new instance of the struct. 
	//		These are often called new , but new isn’t a special name and 
	//		isn’t built into the language

	//		Because It Doesn't Take self As First Argument
	
	// Factory Function i.e. Function Which Creates Objects
	//		square Function Creating Object Of Self Type i.e. RectangleAgain
	//		Called Using :: Followed By Type Name

	// Factory Function: Function Creates Object(s)
	fn square( size: u32 ) -> Self {
		Self {
			width: size,
			height: size
		}
	}

}


fn play_with_rectanlge_again_methods() {

	let rectangle1 = RectangleAgain {
		width: 30,
		height: 50,
	};

	let rectangle2 = RectangleAgain {
		width: 20,
		height: 40,
	};

	// Methods Are Called Using . Operator After Object
	println!("Rectangle Area : {}", rectangle1.area() );
	println!("Rectangle Width: {}", rectangle1.is_width() );	
	println!("Rectangle Can Hold : {}", rectangle1.can_hold( &rectangle2 ) );

	// Calling Associative Function
	RectangleAgain::square( 99 );
}

//_____________________________________________________________

// Methods are similar to functions: we declare them with the fn keyword and a name, they
// can have parameters and a return value, and they contain some code that’s run when the
// method is called from somewhere else. Unlike functions, methods are defined within the
// context of a struct (or an enum or a trait object

// and their first parameter is always self , which represents the instance of the
// struct the method is being called on.

// instead of rectangle: &Rectangle . The &self is actually short for self: &Self . 

// Within an impl block, the type Self is an alias for the type
// that the impl block is for. Methods must have a parameter named 
// self of type Self for their first parameter, so Rust lets you 
// abbreviate this with only the name self in the first parameter spot. 

// Note that we still need to use the & in front of the self shorthand to
// indicate this method borrows the Self instance, 

// Just as we did in rectangle: &Rectangle . Methods can take ownership of self, 
// borrow self immutably as we’ve done here, or borrow self mutably, 
// just as they can any other parameter.

// We’ve chosen &self here for the same reason we used &Rectangle in the function version:
// we don’t want to take ownership, and we just want to read the data in the struct, 
// not write to it. If we wanted to change the instance that we’ve called the method 
// on as part of what the method does, we’d use &mut self as the first parameter.

// Note that we can choose to give a method the same name as one of the struct’s fields.
// 		when we follow rect1.width with parentheses, 
//				Rust knows we mean the method width . 
//		When we don’t use parentheses, 
//				Rust knows we mean the field width .

//_____________________________________________________________


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\nFunction : play_with_user");
	play_with_user();

	println!("\nFunction : play_with_build_user");
	play_with_build_user();

	println!("\nFunction : play_with_area");
	play_with_area();

	println!("\nFunction : play_with_custom_tuple_types");
	play_with_custom_tuple_types();

	println!("\nFunction : play_with_struct_without_fields");
	play_with_struct_without_fields();

	println!("\nFunction : play_with_rectanlge_again_methods");
	play_with_rectanlge_again_methods();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}


