//_____________________________________________________________

Write Following sum Function In C Language
Submit Your Answers In Chat Window

// It's Summation of Mathematical Integer 
int sum( int a, int b ) {
	return a + b;
}

//_____________________________________________________________

Write Following sum Function In C Language
Submit Your Answers In Chat Window

// It's Summation of Mathematical Integer 
//		It Should Return Valid Arithmatic Integer Sums
int sum( int a, int b ) {

}

Design #Design #2
using long or long long as return type of function

long sum(int a, int b) { 
	return (long) a + (long) b;
} 

// Guaranteed not to overflow integer sum, 
//		but is architecture dependent assuming 
//		sizeof(long) => sizeof(int)

// char < short <= int <= long <= long long

Design #3

//Range of Int = [ INT_MIN, INT_MAX ]

int sum(int a, int b, int *result) {
  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        return 0; // overflow or underflow
    }
    *result = a + b;
    return 1; // success
}

Design #4
The issue is in your function signature, to have the return type of int and 
two params of int, we can not safely sum in C across all possible, so we should 
either change the return type, or indicate when this can not be done within 
the int we expect.

Design #5
bool sum (int a, int b, int *result)
{
    // Case 1: Both numbers are positive
    // (risk of Overflow)
    if (a > 0 && b > 0) {
        if (a > INT_MAX - b) {
            printf("Overflow detected!\n");
            return false;
         } 
     } 

     // Case 2: Both numbers are negative (risk of Underflow) 
     else if (a < 0 && b < 0) { 
     	if (a < INT_MIN - b) { 
     		printf("Error: Integer Underflow detected!\n"); 
     		return false; 
     	} 
     } // If one is positive and one is negative, overflow/underflow is impossible. *result = a + b; return true; }

