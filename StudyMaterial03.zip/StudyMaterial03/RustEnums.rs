#![allow(unused)]
//_____________________________________________________________

enum IpAddrKind {
	V4,
	V6,
}

fn route( ip_kind : IpAddrKind ) {
	// Dummy Function... with ...
}

fn play_with_ipaddress_enum() {
	let four = IpAddrKind::V4;
	let six = IpAddrKind::V6;

	route( IpAddrKind::V4 );
	route( six )
}


//_____________________________________________________________

fn play_with_ipaddress_enum1() {
	// Associative Types
	//		Sum Type
    enum IpAddrKind {
        V4,
        V6,
    }

	// Associative Types
	//		Product Type
    struct IpAddr {
    	// Composing 
        kind: IpAddrKind,  // 2
        address: String,   // 225 * 255 * 255 * 255
    }


    let some: IpAddrKind = IpAddrKind::V4;
    // let some_again: IpAddr = ???; // 2 * 225 * 255 * 255 * 255

    let home = IpAddr {
        kind: IpAddrKind::V4,
        address: String::from("127.0.0.1"),
    };

    let loopback = IpAddr {
        kind: IpAddrKind::V6,
        address: String::from("::1"),
    };

}

//_____________________________________________________________

fn play_with_ipaddress_enum2() {
	// Associative Types
    enum IpAddr {
        V4(String),
        V6(String),
    }

	// // Associative Types
    // struct IpAddr {
    // 	// Composing 
    //     kind: IpAddrKind,  // 2
    //     address: String,   // 225 * 255 * 255 * 255
    // }


    let home 		= IpAddr::V4( String::from("127.0.0.1"));
    let loopback 	= IpAddr::V4( String::from("::1"));
}


//_____________________________________________________________

fn play_with_ipaddress_enum3() {
	// Associative Types

	#[derive(PartialEq)]
    enum IpAddr {
        V4(u8, u8, u8, u8),
        V6(String),
    }

	// // Associative Types
    // struct IpAddr {
    // 	// Composing 
    //     kind: IpAddrKind,  // 2
    //     address: String,   // 225 * 255 * 255 * 255
    // }


    let home 		= IpAddr::V4( 127, 0, 0, 1 );
    let home1 		= IpAddr::V4( 127, 0, 0, 1 );

   let loopback 	= IpAddr::V6( String::from("::1"));

    let result =  home == home1;
    println!("Result : {:?}", result );
}


//_____________________________________________________________


fn play_with_ipaddress_enum4() {
    struct Ipv4Addr {
        // --snip--
        // part1: u8,
        // part2: u8,
        // part3: u8,
        // part4: u8,
    }

    struct Ipv6Addr {
        // --snip--
    }

    enum IpAddr {
        V4(Ipv4Addr),
        V6(Ipv6Addr),
    }
}

//_____________________________________________________________

/*
enum MessageType {
	JOIN, EXIT, ACTIVE
}

class Message {
	String MessageType
	String TextMessage
	String ImageMessage
	String StatusMessage
}

Message join = new Message( JOIN, Null, Null, Null )
Message exit = new Message( EXIT, Null, Null, Null )
Message post = new Message( ACTIVE, "Hello! How are you doing?", Null, Null )

// Illegal Message
Message m = new Message( JOIN, "Hello! How are you doing?", Null, Null )
*/

fn play_with_message_enum() {
// Creating Type Message
//		Set Of Value 		= { Quit, Move, Write, ChangeColor }
//		Set Of Operation 	= { call() }

// Associative Types
//		Enum Are Sum Type

// BEST PRACTICE: 
//		Always Use Sum Types Over Product Types To Simulate Domain Knowledge
    
    enum Message {
    	Join,
        Quit,
        Move { x: i32, y: i32 },
        Write(String),
        ChangeColor(i32, i32, i32),
    }

    impl Message {
    	// Methods
        fn call(&self) {
            // method body would be defined here
        }
    }

    let m = Message::Write(String::from("hello"));
    m.call();
}

//_____________________________________________________________

fn play_with_optional() {
	let some_char = Some( 'E' );

	let some_number	  : Option<i32>  = Some( 66 );
	let invalid_number: Option<i32>  = None;

	let x : i32 = 55;
	// 	x = None;
	// ^^^^ expected `i32`, found `Option<_>`

	let mut y: Option<i32> = Some( 55 );
	println!("Value: {:?}", y );
	y = None;
	println!("Value: {:?}", y );
}


//_____________________________________________________________
// PATTERN MATCHING

// Type Coin
//		Range = { 	Penny, Nickel, Dime, Quarter }
enum Coin {
	Penny,
	Nickel,
	Dime,
	Quarter,
}


fn value_in_cents( coin: Coin ) -> u8 {
	// match Is An Type Safe Expression
	//		It Has Return Value
	match coin {
		Coin::Penny 	=> 1,
		Coin::Nickel 	=> 5,
		Coin::Dime 		=> 10,
		Coin::Quarter 	=> 25,
	}
}

fn value_in_cents1( coin: Coin ) -> u8 {
	// match Is An Type Safe Expression
	//		It Has Return Value
	let result = match coin {
		Coin::Penny 	=> 1,
		Coin::Nickel 	=> 5,
		Coin::Dime 		=> 10,
		Coin::Quarter 	=> 25,
		// Coin::Quarter 	=> "Hello",
		// error[E0308]: `match` arms have incompatible types
	};

	result 
}

fn play_with_coins() {
    println!("Value : {}", value_in_cents( Coin::Penny ));
    println!("Value : {}", value_in_cents( Coin::Dime ));
    println!("Value : {}", value_in_cents( Coin::Quarter ));

    println!("Value : {}", value_in_cents1( Coin::Penny ));
    println!("Value : {}", value_in_cents1( Coin::Dime ));
    println!("Value : {}", value_in_cents1( Coin::Quarter ));
}

//_____________________________________________________________

// In Rust
//		Definition Of Option Type As Follows:
// pub enum Option<T> {
// 		None,
// 		Some(T),
// }

// There is Bug Fix This Code
fn sum(a : i32, b:i32 ) -> Option<i32> {  
	let min_val = i32::MIN;
    let max_val = i32::MAX;
    let mut result: Option<i32> = None;

    if ((b > 0 && a > max_val - b) ||
        (b < 0 && a < min_val - b)) {
        result = None; // overflow or underflow // Invalid Value
    }

	let result: Option<i32> = Some( a + b ); // Valid Value
    result
}


//_____________________________________________________________


fn play_with_returing_optional() {

    fn plus_one(x: Option<i32>) -> Option<i32> {
        match x {
            None 	=> None,
            Some(i) => Some(i + 1),
        }
    }

    let five 	= Some(5);
    let six 	= plus_one(five);
    let none 	= plus_one(None);

    // fn plus_one_again(x: Option<i32>) -> Option<i32> {
    //     match x {
        	 // ^ pattern `None` not covered
    //         Some(i) => Some(i + 1),
    //     }
    // }

    // let five1 = Some(5);
    // let six1 = plus_one_again(five);
    // let none1 = plus_one_again(None);
}


//______________________________________________________________


fn play_with_match_default() {
    let dice_roll = 9;

    match dice_roll {
        3 		=> add_fancy_hat(),
        7 		=> remove_fancy_hat(),
        other 	=> move_player(other), // Default Case
// ^^^^^^^^^ patterns `i32::MIN..=2_i32`, `4_i32..=6_i32` and `8_i32..=i32::MAX` not covered
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn move_player(num_spaces: u8) {}
}


//_________________________________________________________

fn play_with_match_underscore() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => reroll(), // _ Means Default Case
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn reroll() {}
}


//_________________________________________________________

fn play_with_match_underscore1() {
    let dice_roll = 9;

    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => (),
        // 10 => 99,

    }

    fn add_fancy_hat() 		{		}
    fn remove_fancy_hat() 	{		}
}

//______________________________________________________________

#[derive(Debug)]
enum TypeWrapper {
    Alphanum(String),
    Letter(char),
    Integer(i64),
    Floating(f64),
}

impl TypeWrapper {
    fn util_extract_typewrapper(value: TypeWrapper) -> String {
        match value {
            TypeWrapper::Alphanum(i) 	=> i,
            TypeWrapper::Letter(i)		=> i.to_string(),
            TypeWrapper::Integer(i) 	=> i.to_string(),
            TypeWrapper::Floating(i) 	=> i.to_string(),
        }
    }
}

fn play_with_enum_inner_values() {
    let something = TypeWrapper::Letter('m');
    println!("\n The wrapped up value is:   {:?} \n", something);

    let value = TypeWrapper::util_extract_typewrapper(something);
    println!("\n The value as a String is :   {} \n", value);
    
    value.chars().next().unwrap();
    println!("\n The value as a char is :   {} \n", value);
}

//_____________________________________________________________

// The Option could be something or it could be nothing.

// Rust doesn’t have the null feature that many other languages have. 
//	Null is a value that means there is no value there. In languages with
// 	null, variables can always be in one of two states: null or not-null.

// In his 2009 presentation
// Null References: The Billion Dollar Mistake,” Tony Hoare, the
// inventor of null

// Rust does not have nulls, but it does have an enum that can encode the concept of a value
// being present or absent. This enum is Option<T>, and it is defined by the standard library
// as follows:

// pub enum Option<T> {
// 		None,
// 		Some(T),
// }


// The Option<T> enum is so useful that it’s even included in the prelude; you don’t need to
// bring it into scope explicitly. Its variants are also included in the prelude: you can use Some
// and None directly without the Option:: prefix. The Option<T> enum is still just a regular
// enum, and Some(T) and None are still variants of type Option<T>.

// <T> means the Some variant of the Option enum can hold one piece of data
// of any type, and that each concrete type that gets used in place of T makes the overall
// Option<T> type a diﬀerent type.

//_____________________________________________________________

fn play_with_if_let() {
	let config_max = Some( 7878 );

	// if let idiom
	if let Some( max ) = config_max  {
		print!("Value: {}", max );
	}
}


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________


fn main() {
	println!("\nFunction : play_with_ipaddress_enum");
	play_with_ipaddress_enum();

	println!("\nFunction : play_with_ipaddress_enum1");
	play_with_ipaddress_enum1();

	println!("\nFunction : play_with_ipaddress_enum2");
	play_with_ipaddress_enum2();

	println!("\nFunction : play_with_ipaddress_enum3");
	play_with_ipaddress_enum3();

	println!("\nFunction : play_with_message_enum");
	play_with_message_enum();

	println!("\nFunction : play_with_optional");
	play_with_optional();

	println!("\nFunction : play_with_coins");
	play_with_coins();

	println!("\nFunction : play_with_enum_inner_values");
	play_with_enum_inner_values();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}


