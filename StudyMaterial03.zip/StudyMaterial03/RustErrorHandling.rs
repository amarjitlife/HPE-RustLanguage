
use std::fs;
use std::io;

use std::fs::File;
use std::io::ErrorKind;
use std::io::{self, Read};

//_____________________________________________________________

// Rust groups errors into two major categories: 
		// recoverable and unrecoverable errors. 
// For a recoverable error, such as a file not found error, 
// we most likely just want to report the
// problem to the user and retry the operation. 

// Unrecoverable errors are always symptoms of
// bugs, like trying to access a location beyond the end of an array, 
// and so we want to immediately stop the program.

// Most languages don’t distinguish between these two kinds of 
// errors and handle both in the same way, using mechanisms 
// such as exceptions. 

// Rust doesn’t have exceptions. Instead, it
// has the type Result<T, E> for recoverable errors and 
// the panic! macro that stops execution when the program encounters 
// an unrecoverable error.

//_____________________________________________________________

fn play_with_panic() {
	// panic!("crash and burn");

	let _v = vec![1, 2, 3];
	// v[99];
}

//_____________________________________________________________


// Result Type
// enum is defined as having two variants, Ok and Err, 

// enum Result<T, E> {
// 		Ok(T),
// 		Err(E),
// }

fn play_with_result_type(){
	let greeting_file_result = File::open("hello.txt");

	let greeting_file = match greeting_file_result {
		Ok(ref file) 		=> file,
		Err(error)		=> panic!("Failed to Open File: {:?}", error),
	};

	println!(" Result {:?}", greeting_file);
	println!(" Result {:?}", greeting_file_result);
}

// The return type of File::open is a Result<T, E> . The generic parameter T has 
// been filled in by the implementation of File::open with the type of 
//	the success value, std::fs::File, which is a file handle. 
//	The type of E used in the error value is std::io::Error

// Note that, like the Option enum, the Result enum and its variants have been brought into
// scope by the prelude, so we don’t need to specify Result:: before the Ok and Err
// variants in the match arms.

//_____________________________________________________________

// use std::fs::File;
// use std::io::ErrorKind;

fn play_with_error_handling() {
    let greeting_file_result = File::open("hello.txt");

    let greeting_file = match greeting_file_result {
        Ok(file) => file,
        Err(error) => match error.kind() {
            ErrorKind::NotFound => match File::create("hello.txt") {
                Ok(fc) => fc,
                Err(e) => panic!("Problem creating the file: {e:?}"),
            },
            _ => {
                panic!("Problem opening the file: {error:?}");
            }
        },
    };
}

//_____________________________________________________________

// use std::fs::File;
// use std::io::ErrorKind;

fn play_with_error_handling1() {
    let greeting_file = File::open("hello.txt").unwrap_or_else(|error| {
        if error.kind() == ErrorKind::NotFound {
            File::create("hello.txt").unwrap_or_else(|error| {
                panic!("Problem creating the file: {error:?}");
            })
        } else {
            panic!("Problem opening the file: {error:?}");
        }
    });


    let greeting_file = File::open("hello.txt")
        .expect("hello.txt should be included in this project");


    let nothing: Option<i32> = None;

    //Not Good Practices
    // nothing.unwrap();
    // Optionals To Be Checked With Pattern Matching
}

//_____________________________________________________________

// use std::fs::File;
// use std::io::{self, Read};

fn read_username_from_file() -> Result<String, io::Error> {
    let username_file_result = File::open("hello.txt");

    let mut username_file = match username_file_result {
        Ok(file) => file,
        Err(e) => return Err(e), // Error Propogation
    };

    let mut username = String::new();

    match username_file.read_to_string(&mut username) {
        Ok(_) => Ok(username),
        Err(e) => Err(e),
    }
}

//_____________________________________________________________

// use std::fs::File;
// use std::io::{self, Read};

fn read_username_from_file1() -> Result<String, io::Error> {
    let mut username_file = File::open("hello.txt")?;
    let mut username = String::new();
    username_file.read_to_string(&mut username)?;

    Ok(username)
}


//_____________________________________________________________

// use std::fs::File;
// use std::io::{self, Read};

fn read_username_from_file2() -> Result<String, io::Error> {
    let mut username = String::new();

    // ?. Safe Access Operator
    File::open("hello.txt")?.read_to_string(&mut username)?;

    Ok(username)
}

// use std::fs;
// use std::io;

fn read_username_from_file() -> Result<String, io::Error> {
    fs::read_to_string("hello.txt")
}

//_____________________________________________________________

// This error points out that we’re only allowed to use the ? operator 
// in a function that returns Result, Option, or another type 
// that implements FromResidual.

// To fix the error, you have two choices. One choice is to change 
// the return type of your function to be compatible with the 
// value you’re using the ? operator on as long as you have 
// no restrictions preventing that. The other choice is to use a 
// match or one of the Result<T, E> methods to handle 
// the Result<T, E> in whatever way is appropriate.

// The error message also mentioned that ? can be used with Option<T> 
// values as well. As with using ? on Result, you can only use ? on Option 
// in a function that returns an Option. 

// The behavior of the ? operator when called on an Option<T> 
// is similar to its behavior when called on a Result<T, E>: 
// If the value is None, the None will be returned early 
// from the function at that point. If the value is Some, 
// the value inside the Some is the resultant value of 
// the expression, and the function continues.

//_____________________________________________________________

fn last_char_of_first_line(text: &str) -> Option<char> {
	// Optional Chaining
    text.lines().next()?.chars().last()
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________


fn main() {
	println!("\nFunction : play_with_panic");
	play_with_panic();

	// println!("\nFunction : play_with_result_type");
	// play_with_result_type();

	println!("\nFunction : play_with_error_handling");
	play_with_error_handling();

	println!("\nFunction : play_with_error_handling1");
	play_with_error_handling1();

	println!("\nFunction : read_username_from_file");
	read_username_from_file();

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}

